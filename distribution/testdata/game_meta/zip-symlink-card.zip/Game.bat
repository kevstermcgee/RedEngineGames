@echo off
echo hi
