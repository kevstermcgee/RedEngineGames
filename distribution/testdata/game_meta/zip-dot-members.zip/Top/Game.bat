@echo off
REM redengine-game
REM name: Bat Name
REM description: From the bat.
echo running
