@echo off
REM redengine-game
REM name: Nul Name
echo running
