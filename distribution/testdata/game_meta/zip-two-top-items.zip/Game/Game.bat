@echo off
REM redengine-game
REM name: Bat Name
REM description: Down one folder.
echo running
