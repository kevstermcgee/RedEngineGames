@echo off
REM redengine-game
REM name: Aux Quest
echo running
